#%%
import pandas as pd
import numpy as np
file_path = r'C:\Users\Mohammed\InputDataNEW - Copy -2.xlsx'

excel_data = pd.ExcelFile(file_path, engine='openpyxl')


Sets_data = excel_data.parse('Set')
Country_data=excel_data.parse('Interconnection')
Line_data=excel_data.parse('Sheet1')
df_CAP=excel_data.parse('Capacity', header=None, usecols="A:AI", skiprows=1, nrows=460)

df_Land = excel_data.parse('Land', header=None, usecols="A:AH", skiprows=2, nrows=3)

#df_Dem = excel_data.parse('TWh Demand2', header=None, usecols="A:AH", skiprows=1, nrows=18)
df_Dem = excel_data.parse('Sheet6', header=None, usecols="A:AH", skiprows=1, nrows=28)

Load_data=excel_data.parse('TWh Demand')
Load_data2=excel_data.parse('TWh Demand2')
Load_data3=excel_data.parse('AI facttories')
ComY_data=excel_data.parse('Connection')
df_Peak=excel_data.parse('TWh Demand2', header=None, usecols="A:AH", skiprows=89, nrows=18)
df_emTarget = excel_data.parse('CO2target', header=None, usecols="A:AH", skiprows=2, nrows=28)
df_Fuel = excel_data.parse('Fuel Cost', header=None, usecols="A:R", skiprows=1, nrows=28)
df_cap = excel_data.parse('Candidate Capacity', header=None, usecols="C:AJ", skiprows=177, nrows=12)
df_inst = excel_data.parse('Candidate Capacity', header=None, usecols="C:AJ", skiprows=163, nrows=12)
df_capT= excel_data.parse('Candidate Capacity', header=None, usecols="C:AJ", skiprows=190, nrows=12)
df_Trans1 = excel_data.parse('Interconnection', header=None, usecols="H:AN", skiprows=53, nrows=33)
df_Trans = excel_data.parse('Interconnection', header=None, usecols="AR:BX", skiprows=7, nrows=33)
df_Trans2 = excel_data.parse('Interconnection', header=None, usecols="H:AN", skiprows=7, nrows=33)

Emission_data = excel_data.parse('Emission Factor')
Derate_data=excel_data.parse('De-rating')
Cost_data=excel_data.parse('Generation Cost')

df_CF=excel_data.parse('De-rating', header=None, usecols="E:I", skiprows=34, nrows=33)

file_path2 = r'C:\Users\Mohammed\AI_Electricity_Demand_GrowthPatterns.xlsx'
excel_data2 = pd.ExcelFile(file_path2, engine='openpyxl')


df_AIICIS=excel_data2.parse('ICIS', header=None, usecols="B:AI", skiprows=42, nrows=28)
df_AIConservative=excel_data2.parse('Conservative', header=None, usecols="B:AI", skiprows=42, nrows=28)
df_AIMcKinesy=excel_data2.parse('McKinesy', header=None, usecols="B:AI", skiprows=42, nrows=28)
df_AIAmbitious=excel_data2.parse('Ambitious', header=None, usecols="B:AI", skiprows=42, nrows=28)

Peak_dataAIICIS=excel_data2.parse('ICIS')
Peak_dataAIConservative=excel_data2.parse('Conservative')
Peak_dataAIMcKinesy=excel_data2.parse('McKinesy')
Peak_dataAIAmbitious=excel_data2.parse('Ambitious')

#%%
from pyomo.environ import *
from pyomo.environ import SolverFactory
from pyomo.environ import value

model = ConcreteModel()

t_data=Sets_data.iloc[0, 2:29].values
c_data=Sets_data.iloc[1,2:35].values
g1_data=Sets_data.iloc[2,2:19].values
g2_data=Sets_data.iloc[3,2:11].values
Country1_data=ComY_data.iloc[1:177,1].values
Country2_data=ComY_data.iloc[1:177,2].values
Distance_data=ComY_data.iloc[1:177,3]
Candidate_line=ComY_data.iloc[1:177,4]
Type_line=ComY_data.iloc[1:177,5].values
Neighbourhood_Countries = list(zip(Country1_data,Country2_data,Distance_data))

Coutry_Battery=Derate_data.iloc[32:56,1].values

#triples = [(x, y, f"id_{i}") for i, (x, y, _) in enumerate(Neighbourhood_Countries)]
#z_values = {(x, y, f"id_{i}"): z for i, (x, y, z) in enumerate(Neighbourhood_Countries)}

model.c=Set(initialize=c_data)
model.c2=Set(initialize=Coutry_Battery)
model.t=Set(initialize=t_data)
model.g1=Set(initialize=g1_data)
model.g2=Set(initialize=g2_data)
model.Ty = Set(initialize=['HVDC','HVDC-S', 'OHL', 'UG'])

model.TT=RangeSet(2,27)

ids = [f"id_{i}" for i in range(1, len(Country1_data) + 1)]
model.ids=Set(initialize=ids)
# Create list of triples (c, c1, id_)
triples = list(zip(Type_line,Country1_data, Country2_data, ids))

# Create dictionary mapping triple -> Candidate_line value
line_param_dict = dict(zip(triples, Candidate_line))
Distance_dict = dict(zip(triples, Distance_data))

model.NN = Set(dimen=4, initialize=triples)
#%%

Data1 = Emission_data.iloc[1:18, 1:28]  # 3 rows

y_c_data = {
    (g, t): Data1.iloc[i, j]
    for i, g in enumerate(model.g1)
    for j, t in enumerate(model.t)
}

Data2=Emission_data.iloc[20,1:28]
c_p_data={(t): Data2.iloc[i]
          for i, t in enumerate(model.t)
          }
Data3=Derate_data.iloc[1,1:19]
de_data={(g): Data3.iloc[i]
          for i, g in enumerate(model.g1)
          }
Data4=Derate_data.iloc[7,1:19]
eta_data={(g): Data4.iloc[i]
          for i, g in enumerate(model.g1)
          }


Datanew=Derate_data.iloc[32:56,2]
CFb_data={(c): Datanew.iloc[i]
          for i, c in enumerate(model.c2)
          }

techs = ['Solar', 'Wind Onshore', 'Wind Offshore', 'Battery']
CFRES_data = {
    (c, g): df_CF.iloc[i, 1 + g_idx]
    for i, c in enumerate(model.c)
    for g_idx, g in enumerate(techs)
}


Data_CF=Derate_data.iloc[12,1:19]
CF_data={(g): Data_CF.iloc[i]
          for i, g in enumerate(model.g1)
          }


Data_min=Derate_data.iloc[16,1:19]
min_data={(g): Data_min.iloc[i]
          for i, g in enumerate(model.g1)
          }

Data_max=Derate_data.iloc[19,1:19]
max_data={(g): Data_max.iloc[i]
          for i, g in enumerate(model.g1)
          }

Life_data=Derate_data.iloc[26,1:19]
Decom_data={(g): Life_data.iloc[i]
          for i, g in enumerate(model.g1)
          }


Paras_data=Derate_data.iloc[29,1:19]
PL_data={(g): Paras_data.iloc[i]
          for i, g in enumerate(model.g1)
          }
Data_con=Derate_data.iloc[23,1:19]
Construction_data={(g): Data_con.iloc[i]
          for i, g in enumerate(model.g1)
          }

Fuel_data = {(t, g): df_Fuel.iloc[i,  g_idx+1 ]
    for i, t in enumerate(model.t)  
    for g_idx, g in enumerate(model.g1)  
    }

Data5=Cost_data.iloc[2,2:20]
GIC_data={(g): Data5.iloc[i]
          for i, g in enumerate(model.g1)}

Data6=Cost_data.iloc[8,2:20]
GVC_data={(GE): Data6.iloc[i]
          for i, GE in enumerate(model.g1)}

Data7=Cost_data.iloc[11,2:20]
GFOC_data={(GE): Data7.iloc[i]
          for i, GE in enumerate(model.g1)}

#Pcap_e_data={(g,c): df_inst.iloc[i,c_idx+1] 
            # for i, g in enumerate(model.g1)  
             #for c_idx, c in enumerate(model.c) }

#Pcap_data={(g,c): df_cap.iloc[i,  c_idx+1 ]
   # for i, g in enumerate(model.g1)  
    #for c_idx, c in enumerate(model.c)  
   # }
#PcapT_data={(g,c): df_capT.iloc[i,  c_idx+1 ]
    #for i, g in enumerate(model.g1)  
    #for c_idx, c in enumerate(model.c)  
    #}


Pcap_data = {(t, g, c): df_CAP.iloc[i,  2+c_idx]
    for i, (t, g) in enumerate(zip(df_CAP.iloc[:, 0], df_CAP.iloc[:, 1]))  
    for c_idx, c in enumerate(model.c)  
    }


techs = ['Solar', 'Wind Onshore', 'Wind Offshore']
Pland_data = {
    (g, c): df_Land.iloc[i, 1 + c_idx]
    for i, g in enumerate(techs)
    for c_idx, c in enumerate(model.c)
}


Dem_data={(t,c): df_Dem.iloc[i,c_idx+1] 
             for i, t in enumerate(model.t)  
             for c_idx, c in enumerate(model.c) }

#PDem_data={(t,c): df_Peak.iloc[i,c_idx+1] 
            # for i, t in enumerate(model.t)  
            # for c_idx, c in enumerate(model.c) }

Em_data={(t,c): df_emTarget.iloc[i,c_idx+1] 
             for i, t in enumerate(model.t)  
             for c_idx, c in enumerate(model.c) }
Trans_data1 = {
    (g_row, g_col): df_Trans1.iloc[i, j]
    for i, g_row in enumerate(model.c)
    for j, g_col in enumerate(model.c) 
   if df_Trans2.iloc[i, j] > 0
   }

Trans_data2 = {
    (g_row, g_col): df_Trans2.iloc[i, j]
    for i, g_row in enumerate(model.c)
    for j, g_col in enumerate(model.c) 
   if df_Trans2.iloc[i, j] > 0
   }

Trans_data = {
    (g_row, g_col): df_Trans.iloc[i, j]
    for i, g_row in enumerate(model.c)
    for j, g_col in enumerate(model.c) 
    if df_Trans.iloc[i, j] > 0}


#Dem_AI1={t: val for t, val in zip(model.t, df_AI1)}

#Dem_AI={(t,c): df_AI4.iloc[i,c_idx+1] 
           #  for i, t in enumerate(model.t)  
             #for c_idx, c in enumerate(model.c) }


Dem_Lshed=Load_data.iloc[41,1:34]
Lshed_data={(c): Dem_Lshed.iloc[i]
          for i, c in enumerate(model.c)
          }
VOLL_data=Load_data.iloc[42,1:34]
VOLL_price={(c): VOLL_data.iloc[i]
          for i, c in enumerate(model.c)
          }
#Dem_Peak=Load_data.iloc[46,1:35]
#Peak_data={(c): Dem_Peak.iloc[i]
         # for i, c in enumerate(model.c)
         # }

Data10=Load_data2.iloc[107:134,2]
Peak_data={(t): Data10.iloc[i]
          for i, t in enumerate(model.t)}


#Data11=Load_data3.iloc[21:38,1]
#AI_Peak={(t): Data11.iloc[i]
          #for i, t in enumerate(model.t)}

Data12=ComY_data.iloc[1:177,6]
Commition_data={(NN): Data12.iloc[i]
          for i, NN in enumerate(model.NN)}



Dem_AIICIS={(t,c): df_AIICIS.iloc[i,c_idx+1] 
             for i, t in enumerate(model.t)  
             for c_idx, c in enumerate(model.c) }
Dem_AIConservative={(t,c): df_AIConservative.iloc[i,c_idx+1] 
             for i, t in enumerate(model.t)  
             for c_idx, c in enumerate(model.c) }

Dem_AIMcKinesy={(t,c): df_AIMcKinesy.iloc[i,c_idx+1] 
             for i, t in enumerate(model.t)  
             for c_idx, c in enumerate(model.c) }

Dem_AIAmbitious={(t,c): df_AIAmbitious.iloc[i,c_idx+1] 
             for i, t in enumerate(model.t)  
             for c_idx, c in enumerate(model.c) }


Data13=Peak_dataAIICIS.iloc[41:68,35]
AIICIS_Peak={(t): Data13.iloc[i]
          for i, t in enumerate(model.t)}

Data14=Peak_dataAIConservative.iloc[41:68,35]
AIConservative_Peak={(t): Data14.iloc[i]
          for i, t in enumerate(model.t)}


Data15=Peak_dataAIMcKinesy.iloc[41:68,35]
AIMcKinesy_Peak={(t): Data15.iloc[i]
          for i, t in enumerate(model.t)}

Data16=Peak_dataAIAmbitious.iloc[41:68,35]
AIAmbitious_Peak={(t): Data16.iloc[i]
          for i, t in enumerate(model.t)}

#%%
Country_order = {region: i + 1 for i, region in enumerate(model.c)}
model.ord_c = Param(model.c, initialize=Country_order)
#%% Parameters
model.Pcap_T = Param(model.t, model.g1,model.c, initialize=Pcap_data,doc='in GW')
model.PLand = Param( model.g1,model.c, initialize=Pland_data,doc='in GW')

model.GICP=Param(model.g1, initialize=GIC_data, doc='Eur/kW')
model.GVCP=Param(model.g1, initialize=GVC_data,doc='in Eur/MWh')
model.GFOP=Param(model.g1, initialize=GFOC_data,doc='in Eur/MWh')
model.GFCP=Param(model.t,model.g1,initialize=Fuel_data,doc='in Eur/MWh')
model.Cp=Param(model.t,initialize=c_p_data, doc='in Eur/tCO2')
model.y_c=Param(model.g1,model.t,initialize=y_c_data, doc='in tCO2/MWh')
model.eta=Param(model.g1,initialize=eta_data)
model.de=Param(model.g1,initialize=de_data)
model.Pmin=Param(model.g1,initialize=min_data)
model.Pmax=Param(model.g1,initialize=max_data)
model.Tp=Param(model.g1,initialize=Construction_data)
model.Te=Param(model.g1,initialize=Decom_data)
model.PLg=Param(model.g1, initialize=PL_data)
model.PLmaxe=Param(model.c,model.c,initialize=Trans_data1, doc='in MW')
model.PLmaxc=Param(model.NN,initialize=line_param_dict,doc='in MW')
model.PLmax_c=Param(model.c,model.c,initialize=Trans_data2,doc='in MW')
model.CF=Param(model.g1,initialize=CF_data)
model.CFb=Param(model.c,model.g1,initialize=CFRES_data)
model.NE = Set(dimen=2,initialize=model.PLmaxe.keys(), doc='Set of region pairs with nonzero pipeline distances')
#model.NC = Set(dimen=2,initialize=model.PLmaxc.keys(), doc='Set of region pairs with nonzero pipeline distances')
model.TICP = Param(
    model.Ty,
    initialize={
        'HVDC': 742,
        'HVDC-S': 1008,
        'OHL': 150,
        'UG': 1008
    },
    doc='1000 Eur/MW.km transmission line'
)

model.TL = Param(
    model.Ty,
    initialize={
        'HVDC': 0.00005,
        'HVDC-S': 0.00007,
        'OHL': 0.0001,
        'UG': 0.00008
    },
    doc='1000 Eur/MW.km transmission line'
)
model.Dist=Param(model.NN,initialize=Distance_dict)
model.CTarget=Param(model.t,model.c, initialize=Em_data)
model.Dem=Param(model.t,model.c,initialize=Dem_data,doc='TWH demand')
model.ComY=Param(model.NN, initialize=Commition_data)
model.DemShed=Param(model.c,initialize=Lshed_data, doc='TWH AI demand')
model.DPeak=Param(model.t,initialize=Peak_data, doc='TWH AI demand')
def dfc_init(model, t):
    return round(1 / (1 + 0.06) ** ( t - 1), 2)
model.dfc = Param(model.t, initialize=dfc_init,  doc='Discount factor for capital costs in time period t')


def dfo_init(model,t):
    return round(
        1 / (1 + 0.06) ** t,
        2
    )
model.dfo= Param(model.t, initialize=dfo_init)
model.LShed=Param(model.c,initialize=VOLL_price)


model.DemAIICIS=Param(model.t,model.c,initialize=Dem_AIICIS, doc='TWH AI demand')
model.DemAIConservative=Param(model.t,model.c,initialize=Dem_AIConservative, doc='TWH AI demand')
model.DemAIMcKinesy=Param(model.t,model.c,initialize=Dem_AIMcKinesy, doc='TWH AI demand')
model.DemAIAmbitious=Param(model.t,model.c,initialize=Dem_AIAmbitious, doc='TWH AI demand')


model.DemAIPICIS=Param(model.t,initialize=AIICIS_Peak, doc='TWH AI demand')
model.DemAIPConservative=Param(model.t,initialize=AIConservative_Peak, doc='TWH AI demand')
model.DemAIPMcKinesy=Param(model.t,initialize=AIMcKinesy_Peak, doc='TWH AI demand')
model.DemAIPAmbitious=Param(model.t,initialize=AIAmbitious_Peak, doc='TWH AI demand')

#%% Variable Defination 
model.Y = Var(model.NN, model.t, within=Binary)
model.Y1 = Var(model.NE, model.t, within=Binary)

model.AY = Var(model.g1,model.c,model.t, within=NonNegativeReals)
model.AY1 = Var(model.g1,model.c,model.t, within=NonNegativeReals)


model.PLe=Var(model.NE,model.t,within=NonNegativeReals)
model.PL=Var(model.NN,model.t,within=NonNegativeReals)
model.PG=Var(model.g1,model.c,model.t,within=NonNegativeReals)
model.PG1=Var(model.g1,model.c,model.t,within=NonNegativeReals)

model.PGc=Var(model.g1,model.c,model.t,within=NonNegativeReals)
model.PCap_ne=Var(model.g1,model.c,model.t,within=NonNegativeReals)
model.PCap_re=Var(model.g1,model.c,model.t,within=NonNegativeReals)
model.deltaP=Var(model.g1,model.c,model.t,within=NonNegativeReals)
model.Cap=Var(model.g1,model.c,model.t,within=NonNegativeReals)
model.em=Var(model.t,model.c,within=Reals)
model.em2=Var(model.t,model.c,within=Reals)

model.Dshed=Var(model.t,model.c,within=NonNegativeReals)
model.TIC=Var(within=NonNegativeReals)
model.GIC=Var( within=NonNegativeReals)
model.GVC=Var(within=NonNegativeReals)
model.GVC2=Var(within=NonNegativeReals)

model.GVC1=Var(within=NonNegativeReals)
model.GVC3=Var(within=NonNegativeReals)

model.GFOC=Var(within=NonNegativeReals)
model.GFOC1=Var(within=NonNegativeReals)
model.GFC=Var(within=NonNegativeReals)
model.GFC1=Var(within=NonNegativeReals)

model.CC=Var(within=Reals)
model.CC1=Var(within=Reals)
model.TOC=Var(model.c,model.t,within=NonNegativeReals)
model.VOLL=Var(within=NonNegativeReals)
model.Pdelta_ne=Var(model.g1,model.c,model.t,within=NonNegativeReals)
model.Pdelta_re=Var(model.g1,model.c,model.t,within=NonNegativeReals)
model.GIC1=Var(within=NonNegativeReals)

#%% Objective Function and Related Terms
#**Equation (1)**

def objective_rule(model):
    return ( 
        1000*model.GIC+ 
        model.GFC+ 
        model.GVC+
        model.GVC1+
        model.GFOC+
        model.TIC+ 
        model.CC+
        model.VOLL
        
    )   
                  
model.TC = Objective( rule=objective_rule, sense=minimize)

# **Equation (2)** Term of Generation Investment Cost (Equation 2)
def GIC_rule(model):
    return 0.001*model.GIC == 0.001*sum(
        model.dfc[t] * model.GICP[g] * model.PCap_ne[g,c,t]
        for g in model.g1 for c in model.c for t in model.t
    )
model.GICConstraint = Constraint(rule=GIC_rule)


# **Equation (3)**   Term of Generation Fuel Cost
def GFC_rule(model):
    return 0.001*model.GFC == 0.001*sum(
        model.dfo[t] * (model.PG[g,c,t]/model.eta[g])* model.GFCP[t,g]
        for g in model.g1  for c in model.c for t in model.t
    )
model.GFCConstraint = Constraint( rule=GFC_rule)


#*Equation (4)**    Term of Generation Variable Cost
def GVC_rule(model):
    return 0.001*model.GVC == 0.001*sum(
        model.dfo[t] * model.PG[g,c,t]* model.GVCP[g]
        for g in model.g1 if g not in ['Battery', 'Solar','Wind Onshore', 'Wind Offshore'] for c in model.c for t in model.t
    )
model.GVCConstraint = Constraint(rule=GVC_rule)

def GVC_rule1(model):
    return 0.001 * model.GVC1 == 0.001 * sum(
        model.dfo[t] * model.PG[g, c, t] * model.GVCP[g] 
        for g in model.g1 if g in ['Solar', 'Wind Onshore', 'Wind Offshore','Battery']
        for c in model.c
        for t in model.t
    )

model.GVCConstraint1 = Constraint(rule=GVC_rule1)


#**Equation (5)** Term of Generation Fixed Cost

def GFOC_rule(model):
    return 0.001*model.GFOC == 0.001*sum(
        model.dfo[t] * model.AY[g,c,t] *model.GFOP[g]
        for g in model.g1 for c in model.c for t in model.t
    )
model.GFOCConstraint = Constraint(rule=GFOC_rule)



#**Equation (6)**    Term of Carbon Cost
def CC_rule(model):
    return 0.001 *model.CC ==0.001 * (
        sum(model.dfo[t]* model.PG[g,c,t]* model.y_c[g,t]*model.Cp[t] for g in model.g1   for c in model.c for t in model.t)
      )
model.CCConstraint = Constraint(rule=CC_rule)


#**Equation (7)**    Term of VOLL Cost
def VOLL_rule(model):
    return 0.001 *model.VOLL==0.001 *sum (model.dfo[t]*model.LShed[c]*model.Dshed[t,c] for c in model.c for t in model.t)
model.VOLLConstraint=Constraint(rule=VOLL_rule)



#**Equation (8)** Term of Generation Investment Cost
def TIC_rule(model):
     return 0.001 * model.TIC == 0.001 * sum(
            model.dfc[t] * model.PLmaxc[Ty,c, c1,id_]* model.TICP[Ty] * model.Dist[Ty,c, c1,id_]/2 *
            (model.Y[Ty,c, c1,id_, t] - model.Y[Ty,c, c1,id_, t-1])
            for Ty in model.Ty
            for c in model.c
            for c1 in model.c
            for id_ in model.ids
            if (Ty,c, c1,id_) in model.NN# and model.ord_c[c] < model.ord_c[c1]
            for t in model.t if t>=2
    )
model.TICConstraint = Constraint( rule=TIC_rule)

#%% Generation output constraints
#**Equation (9)**

def Gen_rule1(model, g, c, t):
    if g  in ['Battery', 'Solar', 'Wind Onshore', 'Wind Offshore']:
        return model.PG[g, c, t] == model.AY[g, c,t] * model.CFb[c,g] * 8760
    else:   
        return model.PG[g, c, t] <= model.AY[g, c,t] * model.Pmax[g] * model.CF[g] * 8760

model.ExGenerationConstraint1 = Constraint(model.g1, model.c, model.t, rule=Gen_rule1)

#**Equation (10)**
def Gen_rule2(model, g, c, t):
    if g  not in ['Battery', 'Solar', 'Wind Onshore', 'Wind Offshore']:
      return model.PG[g, c, t] >= model.AY[g, c,t] * model.Pmin[g] * model.CF[g] * 8760  
    else:   
       return Constraint.Skip

model.ExGenerationConstraint2 = Constraint(model.g1, model.c, model.t, rule=Gen_rule2)



#%% Capacity Expasnion Constraints

#**Equation (11)**

def TotalCapacity_rule(model, g, c, t):
    t0 = model.t.first()
    if t != t0:
        t_constr = t - model.Tp[g]
        if t_constr in model.t:
            return model.AY[g, c, t] == model.AY[g, c, t-1] + model.PCap_ne[g, c, t_constr] - model.PCap_re[g, c, t]
        else:
           
            return model.AY[g, c, t] == model.AY[g, c, t-1] - model.PCap_re[g, c, t]
    else:
        return model.AY[g, c, t] == model.Pcap_T[1, g, c]
 
model.TotalCapacityConstraint = Constraint(model.g1, model.c, model.t, rule=TotalCapacity_rule)


#**Equation (12)**
def Gen_rule8(model,g,c,t):
        return  model.AY[g,c,t] <=model.Pcap_T[t,g,c]
   
model.CapConstraint8=Constraint(model.g1,model.c,model.t,rule=Gen_rule8)



#**Equation (13)**
def Gen_rule7(model,g,c,t):
    if g in ['Solar', 'Wind Onshore', 'Wind Offshore']:
        return  model.AY[g,c,t] <=model.PLand[g,c]*1000
    return Constraint.Skip
model.CapConstraint7=Constraint(model.g1,model.c,model.t,rule=Gen_rule7)


#**Equation (14)**
def Gen_rule6(model,g,c,t):
    return model.PCap_ne[g, c, t] <=model.BR[g,c,t]*5

model.CapConstraint6 = Constraint(model.t, rule=Gen_rule6)


#**Equation (15)**
def Gen_rule5(model,t):
    total_capacity = sum(model.AY[g, c, t]*model.de[g]  for g in model.g1 for c in model.c)
    total_peak =model.DPeak[t]
    return total_capacity >=1.08* total_peak

model.CapConstraint5 = Constraint(model.t, rule=Gen_rule5)
#%% Carbon Emission Constraints
#**Equation (16)**
def emission_rule(model,t,c):
    return 0.001*model.em[t,c]== 0.001*(
        sum(model.PG[g,c,t]*(model.y_c[g,t]) for g in model.g1)
    )
model.EmissionConstraint=Constraint(model.t,model.c,rule=emission_rule)

# #**Equation (17)**     Emission target
def Em_target_rule(model,t,c):
  return 0.001 *model.em[t,c]<=0.001 *1000*model.CTarget[t,c]
model.EmTargetConstraint=Constraint(model.t,model.c,rule=Em_target_rule)

#%%Load shedding

#**Equation (18)**
def LShed_rule(model,c,t):
   return model.Dshed[t,c] <=model.LShed[c]
model.LShedConstaint=Constraint(model.c,model.t, rule=LShed_rule)
#%%Power Balance Constraints

# #**Equation (19)**
def Power_balance_rule(model,t,c):
    return (0.001*(
      sum(model.PG[g,c,t]*(1-model.PLg[g]) for g in model.g1)+
        sum(model.PLe[c1,c,t]*(1-0.0001*700) for c1 in model.c if (c1,c) in model.NE)+
        sum(model.PL[Ty,c1,c,id_,t]*(1-model.TL[Ty]*model.Dist[Ty,c1, c,id_]) for Ty in model.Ty  for c1 in model.c for id_ in model.ids if (Ty,c1,c,id_) in model.NN)
        )
    >=
       0.001*(sum(model.PLe[c,c1,t]*(1-0.0001*700) for c1 in model.c if (c,c1) in model.NE)+
       sum(model.PL[Ty,c,c1,id_,t]*(1-model.TL[Ty]*model.Dist[Ty,c, c1,id_])for Ty in model.Ty for c1 in model.c for id_ in model.ids  if (Ty,c,c1,id_) in model.NN)+
       (model.Dem[t,c]+model.DemAI)-model.Dshed[t,c]
       ) 
       )
model.PowerBalanceConstraint=Constraint(model.t,model.c,rule=Power_balance_rule)


#%% Transmission and power flow constraints

# #**Equation (20)**
def Trans_rule1(model,c,c1,t):
    if (c,c1) in model.NE:
        return 0.001 *model.PLe[c,c1,t]<=0.001 *model.PLmaxe[c,c1]*8760*0.8
    return model.PLe[c,c1,t]==0
model.ExTransConstraint1=Constraint(model.NE,model.t,rule=Trans_rule1)


#**Equation (21)**
def CapacityActivation_rule(model, Ty, c, c1, id_, t):
    if (Ty,c, c1, id_) in model.NN:
      
            return model.PL[Ty,c, c1, id_, t] <= model.PLmaxc[Ty,c, c1, id_] * 8760 * model.Y[Ty,c, c1, id_, t]*0.9
      
    return Constraint.Skip
model.CapacityConstraint = Constraint(model.NN, model.t, rule=CapacityActivation_rule)

#**Equation (22)**

def Trans_rule2(model,c,c1,t):
    if (c,c1) in model.NE:
        return model.PLe[c,c1,t]>=0
    return Constraint.Skip
model.ExTransConstraint2=Constraint(model.NE,model.t,rule=Trans_rule2)


#**Equation (23)**

def CapacityActivation_rule2(model,Ty, c, c1,id_, t):
    if t >= model.ComY[Ty,c, c1, id_] and (Ty,c,c1,id_) in model.NN :
        return model.PL[Ty,c, c1,id_, t] >=0
    return Constraint.Skip
model.CapacityConstraint2 = Constraint(model.NN, model.t, rule=CapacityActivation_rule2)

#**Equation (24)**
def availbility_rule(model,Ty,c,c1,id_,t):
   if t>model.ComY[Ty,c, c1, id_] and (Ty,c,c1,id_) in model.NN:# and model.ord_c[c] < model.ord_c[c1]:
           return (model.Y[Ty,c,c1,id_,t-1] )<= model.Y[Ty,c,c1,id_,t]
   return Constraint.Skip
model.LineBuiltConstraint = Constraint(model.NN,model.t, rule=availbility_rule)


#%%
opt = SolverFactory('gurobi')
opt.options['Threads'] = 1              
opt.options['Cuts']= 0
opt.options['Presolve']=0
opt.options['MIPGap']=0.0001
results = opt.solve(model, tee=True)

print("Termination Condition:", results.solver.termination_condition)
